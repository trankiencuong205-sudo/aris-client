package com.example.myclient.modules;

import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import org.lwjgl.glfw.GLFW;

/** Bao chunk co nhieu block chua do (ruong, barrel, shulker, hopper, lo, dispenser...). */
public class ChunkFinder extends ChunkScanModule {
    public ChunkFinder() { super("ChunkFinder", GLFW.GLFW_KEY_L, "block chua do", 8); }

    @Override
    protected boolean counts(BlockEntity be) {
        return be instanceof ChestBlockEntity
                || be instanceof BarrelBlockEntity
                || be instanceof ShulkerBoxBlockEntity
                || be instanceof EnderChestBlockEntity
                || be instanceof HopperBlockEntity
                || be instanceof DispenserBlockEntity
                || be instanceof AbstractFurnaceBlockEntity;
    }
}
