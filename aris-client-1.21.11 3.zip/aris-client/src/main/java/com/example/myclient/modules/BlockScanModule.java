package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;
import net.minecraft.block.Block;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Set;

/** Quet tung block trong chunk (moi tick quet 1 chunk chua quet) va bao chunk co du so block mong muon. */
public abstract class BlockScanModule extends Module {
    private final Set<Long> scanned = new HashSet<>();
    private final String label;
    private final int threshold, minY, maxY;
    private ClientWorld lastWorld;

    protected BlockScanModule(String name, int key, String label, int threshold, int minY, int maxY) {
        super(name, Category.BASEFINDING, key);
        this.label = label;
        this.threshold = threshold;
        this.minY = minY;
        this.maxY = maxY;
    }

    protected abstract boolean counts(Block block);

    @Override
    protected void onEnable() { scanned.clear(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (mc.world != lastWorld) { scanned.clear(); lastWorld = mc.world; }

        int r = mc.options.getViewDistance().getValue();
        int pcx = mc.player.getChunkPos().x;
        int pcz = mc.player.getChunkPos().z;

        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                long key = ChunkPos.toLong(cx, cz);
                if (scanned.contains(key)) continue;
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                scanned.add(key);
                scan(chunk, cx, cz);
                return; // chi quet 1 chunk moi tick de khong giat
            }
        }
    }

    private void scan(WorldChunk chunk, int cx, int cz) {
        int bottom = mc.world.getBottomY();
        int top = bottom + mc.world.getHeight() - 1;
        int y0 = Math.max(bottom, minY), y1 = Math.min(top, maxY);
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int count = 0;
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = y0; y <= y1; y++) {
                    pos.set(cx * 16 + x, y, cz * 16 + z);
                    if (counts(chunk.getBlockState(pos).getBlock())) count++;
                }
            }
        }
        if (count >= threshold) {
            mc.player.sendMessage(Text.literal(String.format(
                    "[%s] %d %s tai X=%d Z=%d", getName(), count, label, cx * 16 + 8, cz * 16 + 8)), false);
        }
    }
}
