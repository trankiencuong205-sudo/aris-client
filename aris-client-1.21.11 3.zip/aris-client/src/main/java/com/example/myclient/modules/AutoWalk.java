package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;

public class AutoWalk extends Module {
    public AutoWalk() { super("AutoWalk", Category.PLAYER, -1); }

    @Override
    public void onTick() { mc.options.forwardKey.setPressed(true); }

    @Override
    protected void onDisable() { mc.options.forwardKey.setPressed(false); }
}
