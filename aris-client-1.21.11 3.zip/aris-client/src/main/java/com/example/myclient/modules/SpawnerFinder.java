package com.example.myclient.modules;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;

public class SpawnerFinder extends ChunkScanModule {
    public SpawnerFinder() { super("SpawnerFinder", -1, "spawner", 1); }

    @Override
    protected boolean counts(BlockEntity be) { return be instanceof MobSpawnerBlockEntity; }
}
