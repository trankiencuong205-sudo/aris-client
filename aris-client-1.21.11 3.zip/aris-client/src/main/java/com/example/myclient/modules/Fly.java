package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Bay bang van toc: Space = len, Shift = xuong. Chi dung trong singleplayer / server cho phep. */
public class Fly extends Module {
    public Fly() { super("Fly", Category.MOVEMENT, GLFW.GLFW_KEY_J); }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        Vec3d v = mc.player.getVelocity();
        double y = 0;
        if (mc.options.jumpKey.isPressed()) y = 0.4;
        else if (mc.options.sneakKey.isPressed()) y = -0.4;
        mc.player.setVelocity(v.x, y, v.z);
    }
}
