package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;

/** Bat/tat chu "MyClient" o goc man hinh. */
public class Watermark extends Module {
    public Watermark() { super("Watermark", Category.MISC, -1); }
}
