package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;
import org.lwjgl.glfw.GLFW;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT, GLFW.GLFW_KEY_G); }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
