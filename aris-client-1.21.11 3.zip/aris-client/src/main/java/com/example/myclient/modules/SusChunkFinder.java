package com.example.myclient.modules;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

import java.util.Set;

/** Bao chunk co nhieu block do nguoi choi dat (duoc, ban crafting, lo, giuong...). */
public class SusChunkFinder extends BlockScanModule {
    private static final Set<Block> BLOCKS = Set.of(
            Blocks.TORCH, Blocks.WALL_TORCH, Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH,
            Blocks.LANTERN, Blocks.SOUL_LANTERN, Blocks.CRAFTING_TABLE, Blocks.FURNACE,
            Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.ENCHANTING_TABLE, Blocks.ANVIL);

    public SusChunkFinder() { super("SusChunkFinder", -1, "block nghi do nguoi dat", 10, -64, 320); }

    @Override
    protected boolean counts(Block block) { return BLOCKS.contains(block) || block instanceof BedBlock; }
}
