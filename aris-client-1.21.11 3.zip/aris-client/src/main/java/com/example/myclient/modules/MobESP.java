package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;

/** Lam sang vien (glow) quanh quai de nhin xuyen tuong. Chi la hieu ung phia client. */
public class MobESP extends Module {
    public MobESP() { super("MobESP", Category.RENDER, -1); }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof MobEntity && !e.isGlowing()) e.setGlowing(true);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof MobEntity) e.setGlowing(false);
        }
    }
}
