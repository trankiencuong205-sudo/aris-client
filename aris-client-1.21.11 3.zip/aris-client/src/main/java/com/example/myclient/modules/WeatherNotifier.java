package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;
import net.minecraft.text.Text;

public class WeatherNotifier extends Module {
    private boolean wasRaining;

    public WeatherNotifier() { super("WeatherNotifier", Category.MISC, -1); }

    @Override
    protected void onEnable() { wasRaining = mc.world != null && mc.world.isRaining(); }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        boolean raining = mc.world.isRaining();
        if (raining != wasRaining) {
            wasRaining = raining;
            mc.player.sendMessage(Text.literal(raining
                    ? "[Weather] Troi bat dau mua" : "[Weather] Troi het mua"), false);
        }
    }
}
