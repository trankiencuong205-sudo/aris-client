package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.Module;

/** Bat/tat danh sach module dang chay o goc man hinh (ve trong MyClient). */
public class Hud extends Module {
    public Hud() { super("HUD", Category.RENDER, -1); }
}
