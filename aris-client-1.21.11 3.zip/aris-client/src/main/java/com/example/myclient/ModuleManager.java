package com.example.myclient;

import com.example.myclient.modules.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Movement
        modules.add(new Sprint());
        modules.add(new Fly());
        // Player
        modules.add(new AutoWalk());
        // Render
        modules.add(new Fullbright());
        modules.add(new Hud());
        modules.add(new MobESP());
        // BaseFinding
        modules.add(new StashFinder());
        modules.add(new SpawnerFinder());
        modules.add(new ChunkFinder());
        modules.add(new SusChunkFinder());
        modules.add(new LightFinder());
        // Misc
        modules.add(new WeatherNotifier());
        modules.add(new Watermark());
    }

    public List<Module> getModules() { return modules; }

    public List<Module> in(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.getCategory() == category) out.add(m);
        return out;
    }

    public Module get(Class<? extends Module> type) {
        for (Module m : modules) if (type.isInstance(m)) return m;
        return null;
    }

    public void tick() {
        for (Module m : modules) {
            if (m.getKeyBinding() != null) {
                while (m.getKeyBinding().wasPressed()) m.toggle();
            }
            if (m.isEnabled()) m.onTick();
        }
    }

    // ---- config: luu danh sach module dang bat, moi dong mot ten
    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("myclient-modules.txt");
    }

    public boolean save() {
        try {
            List<String> names = new ArrayList<>();
            for (Module m : modules) if (m.isEnabled()) names.add(m.getName());
            Files.write(configPath(), names);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean load() {
        try {
            if (!Files.exists(configPath())) return false;
            Set<String> names = new HashSet<>(Files.readAllLines(configPath()));
            for (Module m : modules) m.setEnabled(names.contains(m.getName()));
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
