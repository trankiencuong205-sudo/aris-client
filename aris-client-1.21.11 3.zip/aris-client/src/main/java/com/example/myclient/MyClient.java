package com.example.myclient;

import com.example.myclient.modules.Hud;
import com.example.myclient.modules.Watermark;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MyClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("myclient", "main"));

    public static ModuleManager modules;
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));

        modules = new ModuleManager();
        modules.get(Hud.class).setEnabled(true);
        modules.get(Watermark.class).setEnabled(true);
        modules.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) client.setScreen(new ClickGui());
            if (client.player != null && client.world != null) modules.tick();
        });

        HudElementRegistry.addLast(Identifier.of("myclient", "hud"), (context, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            int y = 4;
            if (modules.get(Watermark.class).isEnabled()) {
                context.drawTextWithShadow(mc.textRenderer, "Aris Client", 4, y, 0xFF55FFFF);
                y += 11;
            }
            if (modules.get(Hud.class).isEnabled()) {
                for (Module m : modules.getModules()) {
                    if (m.isEnabled() && !(m instanceof Hud) && !(m instanceof Watermark)) {
                        context.drawTextWithShadow(mc.textRenderer, m.getName(), 4, y, 0xFFFFFFFF);
                        y += 10;
                    }
                }
            }
        });
    }
}
