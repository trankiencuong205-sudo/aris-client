package com.example.myclient;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** ClickGUI kieu panel xanh mo: cong tac gat, thu gon panel, tim module, luu/tai config. */
public class ClickGui extends Screen {
    private static final int COL_W = 112, GAP = 8, HEADER_H = 18, ROW_H = 16, TOP = 26;

    private static int PANEL, HEADER, ACCENT, TRACK_OFF, TEXT_OFF, BTN_HOVER;
    private static final int ROW_HOVER = 0x40FFFFFF;
    private static boolean dark = true;

    static { applyTheme(); }

    private static void applyTheme() {
        if (dark) {
            PANEL = 0xD0101018; HEADER = 0xE01A1A26; ACCENT = 0xFF3B8CFF;
            TRACK_OFF = 0xFF3A3A48; TEXT_OFF = 0xFF9A9AAA; BTN_HOVER = 0xE0303050;
        } else {
            PANEL = 0xB8304878; HEADER = 0xD0223056; ACCENT = 0xFF5AA0FF;
            TRACK_OFF = 0xFF45506E; TEXT_OFF = 0xFFB8C4E0; BTN_HOVER = 0xE05A7AC0;
        }
    }

    private static final Set<Category> collapsed = new HashSet<>();

    private TextFieldWidget search;
    private String query = "";

    public ClickGui() { super(Text.literal("Aris Client")); }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        int w = 180;
        search = new TextFieldWidget(textRenderer, (width - w) / 2, height - 30, w, 16, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Find a module..."));
        search.setMaxLength(30);
        search.setText(query);
        search.setChangedListener(s -> query = s.toLowerCase());
        addDrawableChild(search);
        setInitialFocus(search);
    }

    private List<Module> modulesOf(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MyClient.modules.in(c)) {
            if (query.isEmpty() || m.getName().toLowerCase().contains(query)) out.add(m);
        }
        return out;
    }

    private List<Category> visibleCategories() {
        List<Category> out = new ArrayList<>();
        for (Category c : Category.values()) if (!modulesOf(c).isEmpty()) out.add(c);
        return out;
    }

    private int leftFor(int count) {
        int total = count * COL_W + (count - 1) * GAP;
        return Math.max(8, (width - total) / 2);
    }

    private boolean isOpen(Category c) { return !query.isEmpty() || !collapsed.contains(c); }

    private int saveX() { return search.getX() + search.getWidth() + 6; }
    private int loadX() { return saveX() + 40; }
    private int themeX() { return loadX() + 40; }
    private int btnY() { return search.getY(); }

    private static void rounded(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1 + 1, y1, x2 - 1, y1 + 1, color);
        ctx.fill(x1, y1 + 1, x2, y2 - 1, color);
        ctx.fill(x1 + 1, y2 - 1, x2 - 1, y2, color);
    }

    private static boolean inside(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        List<Category> cats = visibleCategories();
        int left = leftFor(Math.max(1, cats.size()));

        for (int i = 0; i < cats.size(); i++) {
            Category c = cats.get(i);
            List<Module> mods = modulesOf(c);
            int x = left + i * (COL_W + GAP);
            boolean open = isOpen(c);
            int h = HEADER_H + (open ? mods.size() * ROW_H : 0) + 2;

            rounded(ctx, x, TOP, x + COL_W, TOP + h, PANEL);
            rounded(ctx, x, TOP, x + COL_W, TOP + HEADER_H, HEADER);
            ctx.drawTextWithShadow(textRenderer, c.label, x + 6, TOP + 5, 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, open ? "-" : "+", x + COL_W - 12, TOP + 5, TEXT_OFF);

            if (!open) continue;
            int y = TOP + HEADER_H;
            for (Module m : mods) {
                if (inside(mouseX, mouseY, x, y, x + COL_W, y + ROW_H)) {
                    ctx.fill(x + 2, y, x + COL_W - 2, y + ROW_H, ROW_HOVER);
                }
                ctx.drawTextWithShadow(textRenderer, m.getName(), x + 7, y + 4,
                        m.isEnabled() ? 0xFFFFFFFF : TEXT_OFF);

                int tx = x + COL_W - 26, ty = y + 4;
                rounded(ctx, tx, ty, tx + 18, ty + 8, m.isEnabled() ? ACCENT : TRACK_OFF);
                int kx = m.isEnabled() ? tx + 11 : tx + 1;
                ctx.fill(kx, ty + 1, kx + 6, ty + 7, 0xFFFFFFFF);
                y += ROW_H;
            }
        }

        drawButton(ctx, "Save", saveX(), btnY(), mouseX, mouseY);
        drawButton(ctx, "Load", loadX(), btnY(), mouseX, mouseY);
        drawButton(ctx, "Theme", themeX(), btnY(), mouseX, mouseY);
    }

    private void drawButton(DrawContext ctx, String label, int x, int y, int mx, int my) {
        boolean hover = inside(mx, my, x, y, x + 34, y + 16);
        rounded(ctx, x, y, x + 34, y + 16, hover ? BTN_HOVER : HEADER);
        ctx.drawTextWithShadow(textRenderer, label, x + 17 - textRenderer.getWidth(label) / 2, y + 4, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true;
        if (click.button() != 0) return false;

        double mx = click.x(), my = click.y();

        if (inside(mx, my, saveX(), btnY(), saveX() + 34, btnY() + 16)) {
            notify(MyClient.modules.save() ? "Da luu config" : "Luu config that bai");
            return true;
        }
        if (inside(mx, my, loadX(), btnY(), loadX() + 34, btnY() + 16)) {
            notify(MyClient.modules.load() ? "Da tai config" : "Chua co config de tai");
            return true;
        }

        if (inside(mx, my, themeX(), btnY(), themeX() + 34, btnY() + 16)) {
            dark = !dark;
            applyTheme();
            return true;
        }

        List<Category> cats = visibleCategories();
        int left = leftFor(Math.max(1, cats.size()));
        for (int i = 0; i < cats.size(); i++) {
            Category c = cats.get(i);
            int x = left + i * (COL_W + GAP);

            if (inside(mx, my, x, TOP, x + COL_W, TOP + HEADER_H)) {
                if (query.isEmpty()) {
                    if (!collapsed.remove(c)) collapsed.add(c);
                }
                return true;
            }
            if (!isOpen(c)) continue;

            int y = TOP + HEADER_H;
            for (Module m : modulesOf(c)) {
                if (inside(mx, my, x, y, x + COL_W, y + ROW_H)) {
                    m.toggle();
                    return true;
                }
                y += ROW_H;
            }
        }
        return false;
    }

    private void notify(String msg) {
        if (client != null && client.player != null) client.player.sendMessage(Text.literal(msg), true);
    }
}
