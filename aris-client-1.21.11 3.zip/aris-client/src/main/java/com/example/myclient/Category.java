package com.example.myclient;

public enum Category {
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    BASEFINDING("BaseFinding"),
    MISC("Misc");

    public final String label;
    Category(String label) { this.label = label; }
}
