package com.example.myclient.modules;

import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import org.lwjgl.glfw.GLFW;

public class StashFinder extends ChunkScanModule {
    public StashFinder() { super("StashFinder", GLFW.GLFW_KEY_K, "thung chua", 5); }

    @Override
    protected boolean counts(BlockEntity be) {
        return be instanceof ChestBlockEntity
                || be instanceof BarrelBlockEntity
                || be instanceof ShulkerBoxBlockEntity;
    }
}
