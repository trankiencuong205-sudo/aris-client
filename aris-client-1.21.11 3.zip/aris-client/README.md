# Aris Client (Fabric 1.21.11, Yarn)

ClickGUI: Right Shift de mo, ESC de dong.
- Bam tieu de panel de thu gon/mo rong.
- Bam module de bat/tat (cong tac gat).
- Go vao o "Find a module..." de loc module.
- Nut Save / Load: luu / tai danh sach module dang bat (file config/myclient-modules.txt).
  Config duoc tu dong tai khi khoi dong game.

Phim tat: G = Sprint, H = Fullbright, J = Fly, K = StashFinder, L = ChunkFinder. Nut Theme trong GUI doi giua giao dien den va xanh.

Build: `gradlew build` -> build/libs/myclient-1.0.0.jar, bo vao thu muc mods cung Fabric Loader + Fabric API.
Chay thu: `gradlew runClient`.

Neu Gradle bao loi version: tao project moi o https://fabricmc.net/develop/template/ (chon 1.21.11 + Yarn),
roi chep thu muc `src/` cua project nay de len.

Them module: tao class extends Module (category, phim tat hoac -1), them vao ModuleManager.
