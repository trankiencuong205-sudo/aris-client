package com.example.myclient;

import net.minecraft.client.gui.DrawContext;

import java.util.Map;

/** Ve ban do chunk (dung chung cho minimap va ban do toan man hinh). Huong Bac o tren. */
public final class MapRenderer {
    private MapRenderer() {}

    /** px, pz = vi tri nguoi choi tinh theo don vi chunk (toa do block / 16). */
    public static void draw(DrawContext ctx, int x0, int y0, int w, int h, double px, double pz, int s) {
        s = Math.max(1, s);
        ctx.enableScissor(x0, y0, x0 + w, y0 + h);
        ctx.fill(x0, y0, x0 + w, y0 + h, 0xB0000000);

        double cx0 = x0 + w / 2.0, cy0 = y0 + h / 2.0;

        // luoi nhe theo moi chunk khi du to
        for (long key : FoundChunks.scanned) {
            int sx = (int) Math.floor(cx0 + (FoundChunks.chunkX(key) - px) * s);
            int sy = (int) Math.floor(cy0 + (FoundChunks.chunkZ(key) - pz) * s);
            if (sx + s < x0 || sy + s < y0 || sx > x0 + w || sy > y0 + h) continue;
            ctx.fill(sx, sy, sx + s, sy + s, 0x40FFFFFF);
        }

        for (Map.Entry<Long, Map<String, Integer>> e : FoundChunks.found.entrySet()) {
            long key = e.getKey();
            int sx = (int) Math.floor(cx0 + (FoundChunks.chunkX(key) - px) * s);
            int sy = (int) Math.floor(cy0 + (FoundChunks.chunkZ(key) - pz) * s);
            if (sx + s < x0 || sy + s < y0 || sx > x0 + w || sy > y0 + h) continue;
            ctx.fill(sx, sy, sx + s, sy + s, FoundChunks.topColor(e.getValue()));
        }

        // nguoi choi
        int mx = (int) cx0, my = (int) cy0;
        ctx.fill(mx - 1, my - 1, mx + 2, my + 2, 0xFF55FF55);
        ctx.disableScissor();

        // vien
        int c = 0xFF3B8CFF;
        ctx.fill(x0, y0, x0 + w, y0 + 1, c);
        ctx.fill(x0, y0 + h - 1, x0 + w, y0 + h, c);
        ctx.fill(x0, y0, x0 + 1, y0 + h, c);
        ctx.fill(x0 + w - 1, y0, x0 + w, y0 + h, c);
    }
}
