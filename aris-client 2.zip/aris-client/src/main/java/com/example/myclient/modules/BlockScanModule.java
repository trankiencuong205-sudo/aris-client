package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.FoundChunks;
import com.example.myclient.IntSetting;
import com.example.myclient.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Quet tung block trong chunk (moi tick quet 1 chunk chua quet) va bao chunk co du so block mong muon.
 * Che do surface: chi quet quanh MAT DAT (tu "Below" block duoi mat dat toi "Above" block tren mat dat).
 * Che do thuong: quet theo khoang do cao MinY..MaxY.
 */
public abstract class BlockScanModule extends Module {
    private final Set<Long> scanned = new HashSet<>();
    private final String label;
    private final boolean surface;
    private final IntSetting threshold, a, b; // a,b = (Below,Above) hoac (MinY,MaxY)
    private ClientWorld lastWorld;
    private int lastSignature;
    private int scannedCount, foundCount;

    protected BlockScanModule(String name, int key, String label, int defThreshold,
                              int defA, int defB, boolean surface) {
        super(name, Category.BASEFINDING, key);
        this.label = label;
        this.surface = surface;
        this.threshold = intSetting("MinBlocks", defThreshold, 1, 500, 1);
        if (surface) {
            this.a = intSetting("Below", defA, 0, 40, 2);
            this.b = intSetting("Above", defB, 4, 120, 4);
        } else {
            this.a = intSetting("MinY", defA, -64, 320, 8);
            this.b = intSetting("MaxY", defB, -64, 320, 8);
        }
        this.lastSignature = signature();
    }

    protected abstract boolean counts(BlockState state);

    /** Goi truoc khi dem tung chunk (de module con reset bien dem rieng). */
    protected void beginChunk() {}

    /** Cho phep module con loai chunk (vi du lang NPC) sau khi dem xong. */
    protected boolean acceptChunk() { return true; }

    private int signature() { return Objects.hash(threshold.get(), a.get(), b.get()); }

    private String rangeText() {
        return surface
                ? String.format("mat dat -%d..+%d", a.get(), b.get())
                : String.format("Y %d..%d", a.get(), b.get());
    }

    @Override
    protected void onEnable() {
        scanned.clear();
        FoundChunks.clearType(getName());
        scannedCount = 0;
        foundCount = 0;
        lastSignature = signature();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(String.format(
                    "[%s] Dang quet: bao chunk co tu %d %s (%s). Chuot phai module trong menu de chinh.",
                    getName(), threshold.get(), label, rangeText())), false);
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (mc.world != lastWorld) { scanned.clear(); lastWorld = mc.world; }
        if (signature() != lastSignature) { // nguoi dung doi cai dat -> quet lai
            lastSignature = signature();
            scanned.clear();
            FoundChunks.clearType(getName());
            scannedCount = 0;
            foundCount = 0;
        }

        int r = mc.options.getViewDistance().getValue();
        int pcx = mc.player.getChunkPos().x;
        int pcz = mc.player.getChunkPos().z;

        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                long key = ChunkPos.toLong(cx, cz);
                if (scanned.contains(key)) continue;
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                scanned.add(key);
                FoundChunks.markScanned(cx, cz);
                scannedCount++;
                scan(chunk, cx, cz);
                return; // chi quet 1 chunk moi tick de khong giat
            }
        }
    }

    private void scan(WorldChunk chunk, int cx, int cz) {
        int bottom = mc.world.getBottomY();
        int top = bottom + mc.world.getHeight() - 1;
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int count = 0;
        beginChunk();

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int y0, y1;
                if (surface) {
                    int ground = chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, x, z);
                    y0 = Math.max(bottom, ground - a.get());
                    y1 = Math.min(top, ground + b.get());
                } else {
                    y0 = Math.max(bottom, a.get());
                    y1 = Math.min(top, b.get());
                }
                for (int y = y0; y <= y1; y++) {
                    pos.set(cx * 16 + x, y, cz * 16 + z);
                    if (counts(chunk.getBlockState(pos))) count++;
                }
            }
        }

        if (count >= threshold.get() && acceptChunk()) {
            foundCount++;
            FoundChunks.add(getName(), cx, cz, count);
            FoundChunks.recordGround(chunk, cx, cz);
            mc.player.sendMessage(Text.literal(String.format(
                    "[%s] %d %s tai X=%d Z=%d (da quet %d chunk, tim thay %d)",
                    getName(), count, label, cx * 16 + 8, cz * 16 + 8, scannedCount, foundCount)), false);
        }
    }
}
