package com.example.myclient;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final Category category;
    private final KeyBinding keyBinding; // null neu khong co phim tat
    private final List<IntSetting> settings = new ArrayList<>();
    private final List<BoolSetting> boolSettings = new ArrayList<>();
    private boolean enabled;

    /** defaultKey = -1 neu khong muon gan phim. */
    public Module(String name, Category category, int defaultKey) {
        this.name = name;
        this.category = category;
        this.keyBinding = defaultKey < 0 ? null : KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myclient." + name.toLowerCase(),
                InputUtil.Type.KEYSYM,
                defaultKey,
                MyClient.CATEGORY));
    }

    protected IntSetting intSetting(String settingName, int def, int min, int max, int step) {
        IntSetting s = new IntSetting(settingName, def, min, max, step);
        settings.add(s);
        return s;
    }

    protected BoolSetting boolSetting(String settingName, boolean def) {
        BoolSetting s = new BoolSetting(settingName, def);
        boolSettings.add(s);
        return s;
    }

    public List<IntSetting> getSettings() { return settings; }
    public List<BoolSetting> getBoolSettings() { return boolSettings; }
    public String getName() { return name; }
    public Category getCategory() { return category; }
    public KeyBinding getKeyBinding() { return keyBinding; }
    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    /** Ve len HUD moi frame (ESP, day noi...). Chi goi khi module dang bat. */
    public void onHudRender(DrawContext ctx) {}
}
