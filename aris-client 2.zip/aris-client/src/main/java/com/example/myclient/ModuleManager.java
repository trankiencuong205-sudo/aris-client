package com.example.myclient;

import com.example.myclient.modules.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Movement
        modules.add(new Sprint());
        modules.add(new Fly());
        // Player
        modules.add(new AutoWalk());
        // Render
        modules.add(new Fullbright());
        modules.add(new Hud());
        modules.add(new MobESP());
        modules.add(new StorageESP());
        modules.add(new ChunkESP());
        modules.add(new ChunkMap());
        modules.add(new RegionMap());
        // BaseFinding
        modules.add(new StashFinder());
        modules.add(new SpawnerFinder());
        modules.add(new ChunkFinder());
        modules.add(new SusChunkFinder());
        modules.add(new LightFinder());
        // Misc
        modules.add(new WeatherNotifier());
        modules.add(new Watermark());
    }

    public List<Module> getModules() { return modules; }

    public List<Module> in(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.getCategory() == category) out.add(m);
        return out;
    }

    public Module get(Class<? extends Module> type) {
        for (Module m : modules) if (type.isInstance(m)) return m;
        return null;
    }

    public void tick() {
        for (Module m : modules) {
            if (m.getKeyBinding() != null) {
                while (m.getKeyBinding().wasPressed()) m.toggle();
            }
            if (m.isEnabled()) m.onTick();
        }
    }

    // ---- config: moi dong la ten module dang bat, hoac "Module.Setting=gia_tri" (bool: 1/0)
    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("myclient-modules.txt");
    }

    public boolean save() {
        try {
            List<String> lines = new ArrayList<>();
            for (Module m : modules) {
                if (m.isEnabled()) lines.add(m.getName());
                for (IntSetting st : m.getSettings()) {
                    lines.add(m.getName() + "." + st.name + "=" + st.get());
                }
                for (BoolSetting bs : m.getBoolSettings()) {
                    lines.add(m.getName() + "." + bs.name + "=" + (bs.get() ? 1 : 0));
                }
            }
            Files.write(configPath(), lines);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean load() {
        try {
            if (!Files.exists(configPath())) return false;
            Set<String> names = new HashSet<>();
            Map<String, Integer> values = new HashMap<>();
            for (String line : Files.readAllLines(configPath())) {
                int eq = line.indexOf('=');
                if (eq < 0) {
                    names.add(line.trim());
                } else {
                    try {
                        values.put(line.substring(0, eq).trim(), Integer.parseInt(line.substring(eq + 1).trim()));
                    } catch (NumberFormatException ignored) {}
                }
            }
            for (Module m : modules) {
                for (IntSetting st : m.getSettings()) {
                    Integer v = values.get(m.getName() + "." + st.name);
                    if (v != null) st.set(v);
                }
                for (BoolSetting bs : m.getBoolSettings()) {
                    Integer v = values.get(m.getName() + "." + bs.name);
                    if (v != null) bs.set(v != 0);
                }
                m.setEnabled(names.contains(m.getName()));
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
