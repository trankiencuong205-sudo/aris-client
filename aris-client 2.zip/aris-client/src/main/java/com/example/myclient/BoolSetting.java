package com.example.myclient;

/** Cai dat bat/tat cua module, chinh duoc trong ClickGUI (chuot phai vao module de mo). */
public class BoolSetting {
    public final String name;
    private boolean value;

    public BoolSetting(String name, boolean def) {
        this.name = name;
        this.value = def;
    }

    public boolean get() { return value; }
    public void set(boolean v) { value = v; }
    public void toggle() { value = !value; }
}
