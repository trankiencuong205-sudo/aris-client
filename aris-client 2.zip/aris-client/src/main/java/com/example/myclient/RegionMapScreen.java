package com.example.myclient;

import com.example.myclient.modules.RegionMap;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/** Ban do vung danh so toan man hinh: luoi o to mau theo vong, cham do = vi tri ban, o co vien trang = vung hien tai. */
public class RegionMapScreen extends Screen {
    public RegionMapScreen() { super(Text.literal("Region Map")); }

    @Override
    public boolean shouldPause() { return false; }

    private static int ringColor(int k) {
        float t = Math.min(1f, k / 10f);
        return 0xFF000000 | MathHelper.hsvToRgb(0.56f - 0.48f * t, 0.65f, 0.85f);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (client == null || client.player == null) return;
        RegionMap rm = (RegionMap) MyClient.modules.get(RegionMap.class);

        int size = rm.size.get();
        int n = rm.cells.get();
        int half = n / 2;
        double wx = client.player.getX(), wz = client.player.getZ();
        int pgx = RegionMap.cellOf(wx, size), pgz = RegionMap.cellOf(wz, size);
        int cgx = rm.follow.get() ? pgx : 0, cgz = rm.follow.get() ? pgz : 0;

        ctx.fill(0, 0, width, height, 0xB0000008);

        int avail = Math.min(width - 60, height - 100);
        int cell = Math.max(10, avail / n);
        int gridW = cell * n;
        int x0 = (width - gridW) / 2, y0 = (height - gridW) / 2 - 8;

        ClickGui.rr(ctx, x0 - 8, y0 - 22, x0 + gridW + 8, y0 + gridW + 38, 6, 0xE00E0E16);
        ctx.drawTextWithShadow(textRenderer, "REGION MAP  (moi o = " + size + " block)", x0, y0 - 14, 0xFF3B8CFF);

        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                int gx = cgx - half + c, gz = cgz - half + r;
                int k = Math.max(Math.abs(gx), Math.abs(gz));
                int cx = x0 + c * cell, cy = y0 + r * cell;
                ClickGui.rr(ctx, cx + 1, cy + 1, cx + cell - 1, cy + cell - 1, 3, ringColor(k));
                String num = String.valueOf(RegionMap.regionNumber(gx, gz));
                ctx.drawTextWithShadow(textRenderer, num, cx + (cell - textRenderer.getWidth(num)) / 2,
                        cy + (cell - 8) / 2, 0xFFFFFFFF);
                if (gx == pgx && gz == pgz) {
                    int w = 0xFFFFFFFF;
                    ctx.fill(cx, cy, cx + cell, cy + 2, w);
                    ctx.fill(cx, cy + cell - 2, cx + cell, cy + cell, w);
                    ctx.fill(cx, cy, cx + 2, cy + cell, w);
                    ctx.fill(cx + cell - 2, cy, cx + cell, cy + cell, w);
                }
            }
        }

        // cham do = vi tri nguoi choi
        double fx = ((wx + size / 2.0) / size - (cgx - half)) * cell;
        double fz = ((wz + size / 2.0) / size - (cgz - half)) * cell;
        if (fx >= 0 && fx < gridW && fz >= 0 && fz < gridW) {
            int dx = x0 + (int) fx, dz = y0 + (int) fz;
            ctx.fill(dx - 3, dz - 3, dx + 3, dz + 3, 0xFF000000);
            ctx.fill(dx - 2, dz - 2, dx + 2, dz + 2, 0xFFFF3030);
        }

        int ty = y0 + gridW + 6;
        ctx.drawTextWithShadow(textRenderer, "Position: X: " + (int) wx + ", Z: " + (int) wz, x0, ty, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "Current Region: " + RegionMap.regionNumber(pgx, pgz), x0, ty + 11, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer,
                "Cuon chuot: doi so o  |  ESC: dong  |  chinh RegionSize: menu > chuot phai RegionMap",
                x0, ty + 22, 0xFF9A9AAE);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        RegionMap rm = (RegionMap) MyClient.modules.get(RegionMap.class);
        rm.cells.change(verticalAmount > 0 ? -1 : 1);
        return true;
    }
}
