package com.example.myclient.modules;

import com.example.myclient.BoolSetting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.tag.BlockTags;

import java.util.Set;

/**
 * Bao chunk o MAT DAT co nhieu block do nguoi choi dat (go, kinh, gach, cua, giuong, duoc, ban crafting...).
 * IgnoreVillage (bat san): bo qua chunk co chuong lang hoac nhieu duong dat (dau hieu lang NPC) de bao chuan hon.
 */
public class SusChunkFinder extends BlockScanModule {
    private static final Set<Block> BLOCKS = Set.of(
            Blocks.GLASS, Blocks.GLASS_PANE, Blocks.BRICKS, Blocks.STONE_BRICKS, Blocks.COBBLESTONE,
            Blocks.TORCH, Blocks.WALL_TORCH, Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH,
            Blocks.LANTERN, Blocks.SOUL_LANTERN, Blocks.CRAFTING_TABLE, Blocks.FURNACE,
            Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.ENCHANTING_TABLE, Blocks.ANVIL,
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.LADDER);

    private final BoolSetting ignoreVillage = boolSetting("IgnoreVillage", true);
    private boolean bell;
    private int paths;

    public SusChunkFinder() { super("SusChunkFinder", -1, "block nghi do nguoi dat o mat dat", 12, 4, 24, true); }

    @Override
    protected void beginChunk() {
        bell = false;
        paths = 0;
    }

    @Override
    protected boolean counts(BlockState state) {
        Block b = state.getBlock();
        if (b == Blocks.BELL) bell = true;
        else if (b == Blocks.DIRT_PATH) paths++;
        return BLOCKS.contains(b)
                || state.isIn(BlockTags.PLANKS)
                || state.isIn(BlockTags.WOOL)
                || state.isIn(BlockTags.DOORS)
                || state.isIn(BlockTags.FENCES)
                || state.isIn(BlockTags.BEDS);
    }

    @Override
    protected boolean acceptChunk() {
        return !(ignoreVillage.get() && (bell || paths >= 10));
    }
}
