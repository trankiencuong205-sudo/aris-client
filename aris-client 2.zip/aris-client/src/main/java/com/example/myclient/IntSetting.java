package com.example.myclient;

/** Cai dat so nguyen cua module, chinh duoc trong ClickGUI (chuot phai vao module de mo). */
public class IntSetting {
    public final String name;
    public final int min, max, step;
    private int value;

    public IntSetting(String name, int def, int min, int max, int step) {
        this.name = name;
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = Math.max(min, Math.min(max, def));
    }

    public int get() { return value; }
    public void set(int v) { value = Math.max(min, Math.min(max, v)); }
    public void change(int dir) { set(value + dir * step); }
}
