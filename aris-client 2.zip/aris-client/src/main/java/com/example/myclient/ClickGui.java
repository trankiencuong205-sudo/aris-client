package com.example.myclient;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * ClickGUI Aris. Chuot trai: bat/tat module. Chuot phai: mo/dong cai dat cua module.
 * Bam tieu de panel de thu gon. Nut Save / Load / Theme / Map duoi man hinh.
 */
public class ClickGui extends Screen {
    private static final int COL_W = 124, GAP = 8, HEADER_H = 20, ROW_H = 17, TOP = 30;

    private static final Map<String, String> DESC = Map.ofEntries(
            Map.entry("Sprint", "Tu dong chay nhanh khi giu W"),
            Map.entry("Fly", "Bay bang Space / Shift (chi dung trong singleplayer hoac noi cho phep)"),
            Map.entry("AutoWalk", "Tu dong di thang ve phia truoc"),
            Map.entry("Fullbright", "Nhin sang ro trong bong toi"),
            Map.entry("HUD", "Hien danh sach module dang bat o goc trai"),
            Map.entry("MobESP", "Quai phat sang vien, nhin xuyen tuong"),
            Map.entry("ChunkMap", "Minimap chunk o goc phai (phim N: ban do lon)"),
            Map.entry("StashFinder", "Bao chunk co nhieu thung chua"),
            Map.entry("SpawnerFinder", "Bao chunk co spawner"),
            Map.entry("ChunkFinder", "Bao chunk co nhieu block chua do (ruong, hopper, lo...)"),
            Map.entry("SusChunkFinder", "Bao chunk o mat dat nghi co block do nguoi dat"),
            Map.entry("LightFinder", "Bao chunk co nguon sang duoi long dat"),
            Map.entry("WeatherNotifier", "Bao trong chat khi bat dau hoac het mua"),
            Map.entry("StorageESP", "Khung + day noi toi ruong, barrel, shulker, spawner... (chon loai trong cai dat)"),
            Map.entry("ChunkESP", "To mau chunk (om theo dia hinh) + day noi + nhan toi chunk Sus / Spawner / Stash"),
            Map.entry("RegionMap", "Ban do vung danh so (phim M / nut Grid). Bat de hien so vung tren HUD"),
            Map.entry("Watermark", "Hien chu Aris Client o goc trai"));

    // ---- giao dien (0 = Dark, 1 = Blue, 2 = Rainbow)
    private static int theme = 0;
    private static int PANEL, HEAD_A, HEAD_B, TRACK_OFF, TEXT_OFF, BTN, BTN_HOVER, SUB_ROW;

    static { applyTheme(); }

    private static void applyTheme() {
        if (theme == 1) {
            PANEL = 0xE0263C66; HEAD_A = 0xFF35508A; HEAD_B = 0xFF283F70;
            TRACK_OFF = 0xFF45506E; TEXT_OFF = 0xFFB8C4E0; BTN = 0xE0283F70; BTN_HOVER = 0xF05A7AC0; SUB_ROW = 0x90101C3A;
        } else {
            PANEL = 0xE60E0E16; HEAD_A = 0xFF1E1E2C; HEAD_B = 0xFF141420;
            TRACK_OFF = 0xFF34344A; TEXT_OFF = 0xFF9A9AAE; BTN = 0xF01A1A28; BTN_HOVER = 0xF0303050; SUB_ROW = 0x90000008;
        }
    }

    private static int accent(int offset) {
        if (theme == 2) {
            float h = ((System.currentTimeMillis() % 5000L) / 5000f + offset * 0.05f) % 1f;
            return 0xFF000000 | MathHelper.hsvToRgb(h, 0.55f, 1f);
        }
        return theme == 1 ? 0xFF5AA0FF : 0xFF3B8CFF;
    }

    private static final Set<Category> collapsed = new HashSet<>();
    private static final Set<Module> expanded = new HashSet<>();
    private static final Map<Module, Float> anim = new HashMap<>();

    private TextFieldWidget search;
    private String query = "";
    private long openedAt = System.nanoTime(), lastFrame = System.nanoTime();
    private float prog = 0.2f;

    public ClickGui() { super(Text.literal("Aris Client")); }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        int w = 180;
        search = new TextFieldWidget(textRenderer, (width - w) / 2, height - 30, w, 16, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Find a module..."));
        search.setMaxLength(30);
        search.setText(query);
        search.setChangedListener(s -> query = s.toLowerCase());
        addDrawableChild(search);
        setInitialFocus(search);
    }

    // ---------------------------------------------------------------- layout

    private List<Module> modulesOf(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MyClient.modules.in(c)) {
            if (query.isEmpty() || m.getName().toLowerCase().contains(query)) out.add(m);
        }
        return out;
    }

    private List<Category> visibleCategories() {
        List<Category> out = new ArrayList<>();
        for (Category c : Category.values()) if (!modulesOf(c).isEmpty()) out.add(c);
        return out;
    }

    private int leftFor(int count) {
        int total = count * COL_W + (count - 1) * GAP;
        return Math.max(8, (width - total) / 2);
    }

    private boolean isOpen(Category c) { return !query.isEmpty() || !collapsed.contains(c); }

    private int rowsHeight(List<Module> mods) {
        int h = 0;
        for (Module m : mods) {
            h += ROW_H;
            if (expanded.contains(m)) h += (m.getSettings().size() + m.getBoolSettings().size()) * ROW_H;
        }
        return h;
    }

    private static boolean hasSettings(Module m) {
        return !m.getSettings().isEmpty() || !m.getBoolSettings().isEmpty();
    }

    private int topNow() { return TOP + (int) ((1f - prog) * -10f); }

    private int saveX() { return search.getX() + search.getWidth() + 6; }
    private int loadX() { return saveX() + 40; }
    private int themeX() { return loadX() + 40; }
    private int mapX() { return themeX() + 40; }
    private int gridX() { return mapX() + 40; }
    private int btnY() { return search.getY(); }

    // ---------------------------------------------------------------- ve

    private int f(int c) { // ap dung hieu ung mo dan
        int a = (int) ((c >>> 24) * prog);
        if ((c >>> 24) > 0 && a < 6) a = 6;
        return (a << 24) | (c & 0xFFFFFF);
    }

    private static int lerp(int c1, int c2, float t) {
        int a = (int) (((c1 >>> 24) & 255) + (((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Hinh chu nhat bo goc that su. */
    static void rr(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(x2 - x1, y2 - y1) / 2));
        if (r == 0) { ctx.fill(x1, y1, x2, y2, color); return; }
        ctx.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt((double) r * r - d * d));
            ctx.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
            ctx.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
        }
    }

    private static boolean inside(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;
        prog = Math.min(1f, 0.2f + 0.8f * ((now - openedAt) / 180_000_000f));

        // lop toi nhe phia sau menu
        ctx.fill(0, 0, width, height, f(0x70000000));
        super.render(ctx, mouseX, mouseY, delta);

        // tieu de, moi chu mot mau
        String title = "ARIS CLIENT";
        int tx = (width - textRenderer.getWidth(title)) / 2;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            ctx.drawTextWithShadow(textRenderer, ch, tx, 10, f(accent(i)));
            tx += textRenderer.getWidth(ch);
        }

        String hoverDesc = null;
        List<Category> cats = visibleCategories();
        int left = leftFor(Math.max(1, cats.size()));
        int top = topNow();

        for (int i = 0; i < cats.size(); i++) {
            Category c = cats.get(i);
            List<Module> mods = modulesOf(c);
            int x = left + i * (COL_W + GAP);
            boolean open = isOpen(c);
            int h = HEADER_H + (open ? rowsHeight(mods) : 0) + 3;

            // bong do + than panel
            rr(ctx, x - 1, top + 1, x + COL_W + 2, top + h + 3, 6, f(0x50000000));
            rr(ctx, x, top, x + COL_W, top + h, 5, f(PANEL));

            // header gradient + vach mau
            rr(ctx, x, top, x + COL_W, top + HEADER_H, 5, f(HEAD_B));
            ctx.fillGradient(x + 1, top + 2, x + COL_W - 1, top + HEADER_H - 1, f(HEAD_A), f(HEAD_B));
            ctx.fill(x + 3, top + HEADER_H - 1, x + COL_W - 3, top + HEADER_H, f(accent(i * 3)));
            ctx.drawTextWithShadow(textRenderer, c.label, x + 7, top + 6, f(0xFFFFFFFF));

            int on = 0;
            for (Module m : mods) if (m.isEnabled()) on++;
            String cnt = on + "/" + mods.size();
            ctx.drawTextWithShadow(textRenderer, cnt, x + COL_W - 14 - textRenderer.getWidth(cnt), top + 6, f(TEXT_OFF));
            ctx.drawTextWithShadow(textRenderer, open ? "-" : "+", x + COL_W - 11, top + 6, f(TEXT_OFF));

            if (!open) continue;
            int y = top + HEADER_H + 1;
            for (Module m : mods) {
                boolean hover = inside(mouseX, mouseY, x, y, x + COL_W, y + ROW_H);
                if (hover) {
                    rr(ctx, x + 3, y, x + COL_W - 3, y + ROW_H - 1, 3, f(0x30FFFFFF));
                    hoverDesc = DESC.get(m.getName());
                }

                float target = m.isEnabled() ? 1f : 0f;
                float a = anim.getOrDefault(m, target);
                a += (target - a) * Math.min(1f, dt * 14f);
                if (Math.abs(target - a) < 0.01f) a = target;
                anim.put(m, a);

                if (a > 0.02f) ctx.fill(x + 3, y + 2, x + 5, y + ROW_H - 3, f(lerp(0x00000000, accent(i * 3 + 1), a)));
                ctx.drawTextWithShadow(textRenderer, m.getName(), x + 9, y + 5,
                        f(lerp(TEXT_OFF, 0xFFFFFFFF, a)));
                if (hasSettings(m)) {
                    ctx.drawTextWithShadow(textRenderer, expanded.contains(m) ? "v" : ">",
                            x + COL_W - 40, y + 5, f(TEXT_OFF));
                }

                // cong tac truot
                int sx = x + COL_W - 28, sy = y + 4;
                rr(ctx, sx, sy, sx + 22, sy + 10, 5, f(lerp(TRACK_OFF, accent(i * 3 + 1), a)));
                int kx = sx + 1 + Math.round(a * 12);
                rr(ctx, kx, sy + 1, kx + 8, sy + 9, 4, f(0xFFFFFFFF));
                y += ROW_H;

                if (expanded.contains(m)) {
                    for (IntSetting st : m.getSettings()) {
                        rr(ctx, x + 4, y, x + COL_W - 4, y + ROW_H - 1, 3, f(SUB_ROW));
                        ctx.drawTextWithShadow(textRenderer, st.name + ": " + st.get(), x + 11, y + 5, f(0xFFDDDDEE));
                        miniButton(ctx, "-", x + COL_W - 36, y + 2, mouseX, mouseY);
                        miniButton(ctx, "+", x + COL_W - 20, y + 2, mouseX, mouseY);
                        y += ROW_H;
                    }
                    for (BoolSetting bs : m.getBoolSettings()) {
                        rr(ctx, x + 4, y, x + COL_W - 4, y + ROW_H - 1, 3, f(SUB_ROW));
                        ctx.drawTextWithShadow(textRenderer, bs.name, x + 11, y + 5, f(0xFFDDDDEE));
                        int bx = x + COL_W - 32, by = y + 3;
                        rr(ctx, bx, by, bx + 22, by + 10, 5, f(bs.get() ? accent(i * 3 + 1) : TRACK_OFF));
                        int bk = bx + 1 + (bs.get() ? 12 : 0);
                        rr(ctx, bk, by + 1, bk + 8, by + 9, 4, f(0xFFFFFFFF));
                        y += ROW_H;
                    }
                }
            }
        }

        // mo ta khi re chuot vao module
        if (hoverDesc != null) {
            int w = textRenderer.getWidth(hoverDesc) + 14;
            int bx = (width - w) / 2, by = height - 56;
            rr(ctx, bx, by, bx + w, by + 16, 4, f(0xF0101018));
            ctx.drawTextWithShadow(textRenderer, hoverDesc, bx + 7, by + 4, f(0xFFFFFFFF));
        }

        button(ctx, "Save", saveX(), btnY(), mouseX, mouseY);
        button(ctx, "Load", loadX(), btnY(), mouseX, mouseY);
        button(ctx, theme == 0 ? "Dark" : theme == 1 ? "Blue" : "Rainbow", themeX(), btnY(), mouseX, mouseY);
        button(ctx, "Map", mapX(), btnY(), mouseX, mouseY);
        button(ctx, "Grid", gridX(), btnY(), mouseX, mouseY);

        String tip = "Chuot trai: bat/tat   |   Chuot phai: cai dat   |   Bam tieu de: thu gon";
        ctx.drawTextWithShadow(textRenderer, tip, (width - textRenderer.getWidth(tip)) / 2, height - 11, f(TEXT_OFF));
    }

    private void miniButton(DrawContext ctx, String label, int x, int y, int mx, int my) {
        boolean hover = inside(mx, my, x, y, x + 14, y + 12);
        rr(ctx, x, y, x + 14, y + 12, 3, f(hover ? BTN_HOVER : BTN));
        ctx.drawTextWithShadow(textRenderer, label, x + 7 - textRenderer.getWidth(label) / 2, y + 2, f(0xFFFFFFFF));
    }

    private void button(DrawContext ctx, String label, int x, int y, int mx, int my) {
        boolean hover = inside(mx, my, x, y, x + 36, y + 16);
        rr(ctx, x, y, x + 36, y + 16, 4, f(hover ? BTN_HOVER : BTN));
        ctx.drawTextWithShadow(textRenderer, label, x + 18 - textRenderer.getWidth(label) / 2, y + 4, f(0xFFFFFFFF));
    }

    // ---------------------------------------------------------------- click

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true;
        int btn = click.button();
        if (btn != 0 && btn != 1) return false;

        double mx = click.x(), my = click.y();

        if (btn == 0) {
            if (inside(mx, my, saveX(), btnY(), saveX() + 36, btnY() + 16)) {
                notify(MyClient.modules.save() ? "Da luu config" : "Luu config that bai");
                return true;
            }
            if (inside(mx, my, loadX(), btnY(), loadX() + 36, btnY() + 16)) {
                notify(MyClient.modules.load() ? "Da tai config" : "Chua co config de tai");
                return true;
            }
            if (inside(mx, my, themeX(), btnY(), themeX() + 36, btnY() + 16)) {
                theme = (theme + 1) % 3;
                applyTheme();
                return true;
            }
            if (inside(mx, my, gridX(), btnY(), gridX() + 36, btnY() + 16)) {
                if (client != null) client.setScreen(new RegionMapScreen());
                return true;
            }
            if (inside(mx, my, mapX(), btnY(), mapX() + 36, btnY() + 16)) {
                if (client != null) client.setScreen(new ChunkMapScreen());
                return true;
            }
        }

        List<Category> cats = visibleCategories();
        int left = leftFor(Math.max(1, cats.size()));
        int top = topNow();
        for (int i = 0; i < cats.size(); i++) {
            Category c = cats.get(i);
            int x = left + i * (COL_W + GAP);

            if (inside(mx, my, x, top, x + COL_W, top + HEADER_H)) {
                if (btn == 0 && query.isEmpty()) {
                    if (!collapsed.remove(c)) collapsed.add(c);
                }
                return true;
            }
            if (!isOpen(c)) continue;

            int y = top + HEADER_H + 1;
            for (Module m : modulesOf(c)) {
                if (inside(mx, my, x, y, x + COL_W, y + ROW_H)) {
                    if (btn == 0) {
                        m.toggle();
                    } else if (hasSettings(m)) {
                        if (!expanded.remove(m)) expanded.add(m);
                    }
                    return true;
                }
                y += ROW_H;

                if (expanded.contains(m)) {
                    for (IntSetting st : m.getSettings()) {
                        if (btn == 0 && inside(mx, my, x + COL_W - 36, y + 2, x + COL_W - 22, y + 14)) {
                            st.change(-1);
                            return true;
                        }
                        if (btn == 0 && inside(mx, my, x + COL_W - 20, y + 2, x + COL_W - 6, y + 14)) {
                            st.change(1);
                            return true;
                        }
                        y += ROW_H;
                    }
                    for (BoolSetting bs : m.getBoolSettings()) {
                        if (btn == 0 && inside(mx, my, x + 4, y, x + COL_W - 4, y + ROW_H)) {
                            bs.toggle();
                            return true;
                        }
                        y += ROW_H;
                    }
                }
            }
        }
        return false;
    }

    private void notify(String msg) {
        if (client != null && client.player != null) client.player.sendMessage(Text.literal(msg), true);
    }
}
