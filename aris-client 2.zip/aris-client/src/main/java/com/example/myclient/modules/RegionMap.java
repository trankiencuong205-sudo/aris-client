package com.example.myclient.modules;

import com.example.myclient.BoolSetting;
import com.example.myclient.Category;
import com.example.myclient.IntSetting;
import com.example.myclient.Module;
import net.minecraft.client.gui.DrawContext;

/**
 * Ban do vung danh so (luoi o xep xoan oc tu giua, to mau theo vong). Phim M hoac nut Grid trong menu de mo.
 * RegionSize = canh moi o tinh bang block. Chuot phai vao module de chinh. Bat module de hien "Region N" tren HUD.
 */
public class RegionMap extends Module {
    public final IntSetting size = intSetting("RegionSize", 5000, 500, 100000, 500);
    public final IntSetting cells = intSetting("CellsPerSide", 15, 5, 41, 2);
    public final BoolSetting follow = boolSetting("FollowPlayer", false);

    public RegionMap() { super("RegionMap", Category.RENDER, -1); }

    /** O (0,0) la vung 1 nam ngay giua goc toa do, cac vong tiep theo xoan oc ra ngoai. gx: +dong, gz: +nam. */
    public static int regionNumber(int gx, int gz) {
        int k = Math.max(Math.abs(gx), Math.abs(gz));
        if (k == 0) return 1;
        int base = (2 * k - 1) * (2 * k - 1);
        if (gx == k && gz > -k) return base + (gz + k);
        if (gz == k) return base + 2 * k + (k - gx);
        if (gx == -k) return base + 4 * k + (k - gz);
        return base + 6 * k + (gx + k);
    }

    public static int cellOf(double world, int size) {
        return (int) Math.floor((world + size / 2.0) / size);
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        if (mc.player == null) return;
        int s = size.get();
        int gx = cellOf(mc.player.getX(), s), gz = cellOf(mc.player.getZ(), s);
        String text = "Region " + regionNumber(gx, gz) + "   X " + (int) mc.player.getX() + "  Z " + (int) mc.player.getZ();
        int w = mc.textRenderer.getWidth(text);
        ctx.drawTextWithShadow(mc.textRenderer, text, (ctx.getScaledWindowWidth() - w) / 2, 4, 0xFFFFFFFF);
    }
}
