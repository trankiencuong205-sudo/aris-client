package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.IntSetting;
import com.example.myclient.Module;

/** Minimap chunk o goc phai tren man hinh (ve trong MyClient). Chuot phai module de chinh co/zoom. */
public class ChunkMap extends Module {
    public final IntSetting radius = intSetting("Radius", 12, 4, 30, 2);
    public final IntSetting zoom = intSetting("Zoom", 4, 1, 10, 1);

    public ChunkMap() { super("ChunkMap", Category.RENDER, -1); }
}
