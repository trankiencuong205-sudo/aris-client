package com.example.myclient.modules;

import com.example.myclient.BoolSetting;
import com.example.myclient.Category;
import com.example.myclient.IntSetting;
import com.example.myclient.Module;
import com.example.myclient.Projector;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * ESP cho block chua do: khung 2D quanh block + day noi (tracer) + nhan ten/khoang cach.
 * Chon loai block can hien ngay trong cai dat (chuot phai vao module).
 */
public class StorageESP extends Module {
    private static final String[] NAMES = {"Chest", "Barrel", "Shulker", "EnderChest", "Hopper", "Furnace", "Dispenser", "Spawner"};
    private static final int[] COLORS = {
            0xFFFF9A2E, 0xFFC08040, 0xFFB060FF, 0xFFFF40C0, 0xFF9AA0AA, 0xFFD0D0D0, 0xFF6090C0, 0xFF40E0FF};
    private static final boolean[] DEFAULTS = {true, true, true, false, false, false, false, true};

    private final IntSetting range = intSetting("Range", 128, 16, 512, 16);
    private final IntSetting maxTargets = intSetting("MaxTargets", 60, 10, 200, 10);
    private final IntSetting fov = intSetting("FovPercent", 100, 70, 140, 5);
    private final BoolSetting boxes = boolSetting("Boxes", true);
    private final BoolSetting tracers = boolSetting("Tracers", true);
    private final BoolSetting labels = boolSetting("Labels", true);
    private final BoolSetting fromCenter = boolSetting("TracerFromCenter", false);
    private final BoolSetting[] types = new BoolSetting[NAMES.length];

    private static final class Target {
        final BlockPos pos;
        final int type;
        final double dist2;
        Target(BlockPos pos, int type, double dist2) { this.pos = pos; this.type = type; this.dist2 = dist2; }
    }

    private final List<Target> targets = new ArrayList<>();
    private int ticks;

    public StorageESP() {
        super("StorageESP", Category.RENDER, -1);
        for (int i = 0; i < NAMES.length; i++) types[i] = boolSetting(NAMES[i], DEFAULTS[i]);
    }

    @Override
    protected void onEnable() { ticks = 100; }

    @Override
    protected void onDisable() { targets.clear(); }

    private static int classify(BlockEntity be) {
        if (be instanceof ChestBlockEntity) return 0;
        if (be instanceof BarrelBlockEntity) return 1;
        if (be instanceof ShulkerBoxBlockEntity) return 2;
        if (be instanceof EnderChestBlockEntity) return 3;
        if (be instanceof HopperBlockEntity) return 4;
        if (be instanceof AbstractFurnaceBlockEntity) return 5;
        if (be instanceof DispenserBlockEntity) return 6;
        if (be instanceof MobSpawnerBlockEntity) return 7;
        return -1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (++ticks < 10) return;
        ticks = 0;

        targets.clear();
        double r2 = (double) range.get() * range.get();
        int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
        int vr = mc.options.getViewDistance().getValue();
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();

        for (int cx = pcx - vr; cx <= pcx + vr; cx++) {
            for (int cz = pcz - vr; cz <= pcz + vr; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    int t = classify(be);
                    if (t < 0 || !types[t].get()) continue;
                    BlockPos bp = be.getPos();
                    double dx = bp.getX() + 0.5 - px, dy = bp.getY() + 0.5 - py, dz = bp.getZ() + 0.5 - pz;
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r2) continue;
                    targets.add(new Target(bp, t, d2));
                }
            }
        }
        targets.sort(Comparator.comparingDouble(t -> t.dist2));
        while (targets.size() > maxTargets.get()) targets.remove(targets.size() - 1);
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        if (targets.isEmpty() || mc.player == null) return;
        if (!Projector.begin(ctx, fov.get())) return;

        Projector.P c = new Projector.P();
        Projector.P q = new Projector.P();
        for (Target t : targets) {
            int color = COLORS[t.type];
            double x = t.pos.getX(), y = t.pos.getY(), z = t.pos.getZ();

            Projector.project(x + 0.5, y + 0.5, z + 0.5, c);

            if (tracers.get()) Projector.tracer(ctx, c, (color & 0x00FFFFFF) | 0xC0000000, fromCenter.get());
            if (!c.front) continue;

            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
            boolean allFront = true;
            for (int i = 0; i < 8 && allFront; i++) {
                Projector.project(x + (i & 1), y + ((i >> 1) & 1), z + ((i >> 2) & 1), q);
                if (!q.front) { allFront = false; break; }
                minX = Math.min(minX, (int) q.x);
                maxX = Math.max(maxX, (int) q.x);
                minY = Math.min(minY, (int) q.y);
                maxY = Math.max(maxY, (int) q.y);
            }

            if (boxes.get() && allFront) {
                minX = Math.max(-2000, minX); minY = Math.max(-2000, minY);
                maxX = Math.min(4000, maxX); maxY = Math.min(4000, maxY);
                Projector.outline(ctx, minX, minY, maxX, maxY, color);
            }
            if (labels.get()) {
                String text = NAMES[t.type] + " " + (int) Projector.distance(x + 0.5, y + 0.5, z + 0.5) + "m";
                int lx = allFront ? minX : (int) c.x;
                int ly = (allFront ? minY : (int) c.y) - 10;
                Projector.label(ctx, text, lx, ly, color);
            }
        }
    }
}
