package com.example.myclient.modules;

import com.example.myclient.BoolSetting;
import com.example.myclient.Category;
import com.example.myclient.FoundChunks;
import com.example.myclient.IntSetting;
import com.example.myclient.Module;
import com.example.myclient.Projector;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Ve day noi + nhan toi cac chunk ma SusChunkFinder / SpawnerFinder / StashFinder / LightFinder da tim thay.
 * Chon loai chunk can hien trong cai dat.
 */
public class ChunkESP extends Module {
    private final IntSetting range = intSetting("Range", 512, 64, 2048, 64);
    private final IntSetting maxTargets = intSetting("MaxTargets", 30, 5, 100, 5);
    private final IntSetting fov = intSetting("FovPercent", 100, 70, 140, 5);
    private final BoolSetting tracers = boolSetting("Tracers", true);
    private final BoolSetting labels = boolSetting("Labels", true);
    private final BoolSetting fromCenter = boolSetting("TracerFromCenter", false);
    private final BoolSetting sus = boolSetting("Sus", true);
    private final BoolSetting spawner = boolSetting("Spawner", true);
    private final BoolSetting storage = boolSetting("Storage", true);
    private final BoolSetting light = boolSetting("Light", false);
    private final BoolSetting fill = boolSetting("Fill", true);
    private final IntSetting fillAlpha = intSetting("FillAlpha", 90, 20, 200, 10);
    private final IntSetting maxFill = intSetting("MaxFill", 16, 1, 60, 1);
    private final IntSetting fillRange = intSetting("FillRange", 256, 32, 1024, 32);

    private static final class T {
        final long key;
        final double x, z, dist;
        final int color;
        final String text;
        T(long key, double x, double z, double dist, int color, String text) {
            this.key = key; this.x = x; this.z = z; this.dist = dist; this.color = color; this.text = text;
        }
    }

    public ChunkESP() { super("ChunkESP", Category.RENDER, -1); }

    private String describe(Map<String, Integer> types) {
        StringBuilder sb = new StringBuilder();
        if (sus.get() && types.containsKey("SusChunkFinder")) sb.append("SUS ").append(types.get("SusChunkFinder")).append(' ');
        if (spawner.get() && types.containsKey("SpawnerFinder")) sb.append("SPAWNER ");
        if (storage.get()) {
            if (types.containsKey("StashFinder")) sb.append("STASH ").append(types.get("StashFinder")).append(' ');
            else if (types.containsKey("ChunkFinder")) sb.append("STORAGE ").append(types.get("ChunkFinder")).append(' ');
        }
        if (light.get() && types.containsKey("LightFinder")) sb.append("LIGHT ").append(types.get("LightFinder")).append(' ');
        return sb.toString().trim();
    }

    /** To mau ca chunk. Gan: chia 16 o om theo dia hinh. Xa: 1 mang phang. */
    private void fillChunk(DrawContext ctx, T t, double camY) {
        int cx = FoundChunks.chunkX(t.key), cz = FoundChunks.chunkZ(t.key);
        int color = (fillAlpha.get() << 24) | (t.color & 0x00FFFFFF);
        double x0 = cx * 16.0, z0 = cz * 16.0;
        int[] g = FoundChunks.ground.get(t.key);

        if (g == null) {
            fillCell(ctx, x0, z0, 16, camY - 1.5, color);
            return;
        }
        if (t.dist < 64) {
            for (int gz = 0; gz < 4; gz++) {
                for (int gx = 0; gx < 4; gx++) {
                    fillCell(ctx, x0 + gx * 4, z0 + gz * 4, 4, g[gz * 4 + gx] + 0.05, color);
                }
            }
        } else {
            double sum = 0;
            for (int h : g) sum += h;
            fillCell(ctx, x0, z0, 16, sum / g.length + 0.05, color);
        }
    }

    private static void fillCell(DrawContext ctx, double x, double z, double size, double y, int color) {
        Projector.fillQuad(ctx,
                new double[]{x, x + size, x + size, x},
                new double[]{y, y, y, y},
                new double[]{z, z, z + size, z + size},
                color);
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        if (mc.player == null || FoundChunks.found.isEmpty()) return;
        if (!Projector.begin(ctx, fov.get())) return;

        double px = Projector.camPos.x, pz = Projector.camPos.z, py = Projector.camPos.y;
        double r = range.get();
        List<T> list = new ArrayList<>();
        for (Map.Entry<Long, Map<String, Integer>> e : FoundChunks.found.entrySet()) {
            String text = describe(e.getValue());
            if (text.isEmpty()) continue;
            double x = FoundChunks.chunkX(e.getKey()) * 16 + 8, z = FoundChunks.chunkZ(e.getKey()) * 16 + 8;
            double dist = Math.hypot(x - px, z - pz);
            if (dist > r) continue;
            list.add(new T(e.getKey(), x, z, dist, FoundChunks.topColor(e.getValue()), text));
        }
        list.sort(Comparator.comparingDouble(t -> t.dist));

        Projector.P p = new Projector.P();
        int n = Math.min(list.size(), maxTargets.get());
        int filled = 0;
        for (int i = 0; i < n; i++) {
            T t = list.get(i);
            if (fill.get() && filled < maxFill.get() && t.dist <= fillRange.get()) {
                fillChunk(ctx, t, py);
                filled++;
            }
            Projector.project(t.x, py, t.z, p);
            if (tracers.get()) Projector.tracer(ctx, p, (t.color & 0x00FFFFFF) | 0xC0000000, fromCenter.get());
            if (labels.get() && p.front) {
                Projector.label(ctx, t.text + " " + (int) t.dist + "m  X=" + (int) t.x + " Z=" + (int) t.z,
                        (int) p.x - 20, (int) p.y - 10, t.color);
            }
        }
    }
}
