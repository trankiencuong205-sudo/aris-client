package com.example.myclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

/**
 * Chieu diem 3D trong the gioi len toa do man hinh (dung camera that cua game) va ve duong / khung 2D len HUD.
 * Meo: de day noi khop tuyet doi, dat Video Settings > FOV Effects = 0 (hoac chinh FovPercent cua module).
 */
public final class Projector {
    private Projector() {}

    public static final class P {
        /** front = true: x,y la toa do man hinh. false: (x,y) la HUONG tren man hinh (de ve mui ten ra mep). */
        public double x, y;
        public boolean front;
    }

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static Vec3d camPos = Vec3d.ZERO;
    private static double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    private static double tanHalf, aspect;
    public static int sw, sh;

    /** Goi 1 lan moi frame truoc khi project. Tra ve false neu chua co camera. */
    public static boolean begin(DrawContext ctx, int fovPercent) {
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) return false;
        camPos = cam.getCameraPos();
        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        fx = -Math.sin(yaw) * Math.cos(pitch);
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw);
        ry = 0;
        rz = -Math.sin(yaw);
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;

        sw = ctx.getScaledWindowWidth();
        sh = ctx.getScaledWindowHeight();
        double fov = mc.options.getFov().getValue() * (fovPercent / 100.0);
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);
        aspect = (double) sw / (double) sh;
        return true;
    }

    public static void project(double wx, double wy, double wz, P out) {
        double dx = wx - camPos.x, dy = wy - camPos.y, dz = wz - camPos.z;
        double xc = dx * rx + dy * ry + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc > 0.05) {
            out.front = true;
            out.x = sw / 2.0 + (xc / (zc * tanHalf * aspect)) * (sw / 2.0);
            out.y = sh / 2.0 - (yc / (zc * tanHalf)) * (sh / 2.0);
        } else {
            out.front = false;
            out.x = xc;
            out.y = -yc;
        }
    }

    public static double distance(double wx, double wy, double wz) {
        double dx = wx - camPos.x, dy = wy - camPos.y, dz = wz - camPos.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ------------------------------------------------------------- ve

    /** Ve duong thang (da cat theo man hinh) bang cac o vuong t x t. */
    public static void line(DrawContext ctx, double x1, double y1, double x2, double y2, int color, int t) {
        double dx = x2 - x1, dy = y2 - y1;
        double t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x1, sw - x1, y1, sh - y1};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0) {
                    if (r > t1) return;
                    if (r > t0) t0 = r;
                } else {
                    if (r < t0) return;
                    if (r < t1) t1 = r;
                }
            }
        }
        double ax = x1 + dx * t0, ay = y1 + dy * t0, bx = x1 + dx * t1, by = y1 + dy * t1;
        double len = Math.hypot(bx - ax, by - ay);
        int n = Math.max(1, (int) (len / t));
        for (int i = 0; i <= n; i++) {
            int x = (int) (ax + (bx - ax) * i / n);
            int y = (int) (ay + (by - ay) * i / n);
            ctx.fill(x, y, x + t, y + t, color);
        }
    }

    /** Day noi tu goc/giua man hinh toi diem p. Neu diem o sau lung thi ve mui ten huong ra mep. */
    public static void tracer(DrawContext ctx, P p, int color, boolean fromCenter) {
        double ox = sw / 2.0, oy = fromCenter ? sh / 2.0 : sh;
        if (p.front) {
            line(ctx, ox, oy, p.x, p.y, color, 2);
        } else {
            double len = Math.hypot(p.x, p.y);
            if (len < 1e-6) return;
            double far = Math.max(sw, sh) * 2.0;
            line(ctx, ox, oy, ox + p.x / len * far, oy + p.y / len * far, color, 2);
        }
    }

    /** To mau 1 tu giac 3D (4 diem the gioi). Cat theo mat phang gan nen khong loi khi dung tren chunk. */
    public static void fillQuad(DrawContext ctx, double[] wx, double[] wy, double[] wz, int color) {
        double[][] v = new double[4][3];
        for (int i = 0; i < 4; i++) {
            double dx = wx[i] - camPos.x, dy = wy[i] - camPos.y, dz = wz[i] - camPos.z;
            v[i][0] = dx * rx + dy * ry + dz * rz;
            v[i][1] = dx * ux + dy * uy + dz * uz;
            v[i][2] = dx * fx + dy * fy + dz * fz;
        }
        final double near = 0.1;
        double[][] poly = new double[8][];
        int n = 0;
        for (int i = 0; i < 4; i++) {
            double[] a = v[i], b = v[(i + 1) & 3];
            boolean ia = a[2] >= near, ib = b[2] >= near;
            if (ia) poly[n++] = a;
            if (ia != ib) {
                double t = (near - a[2]) / (b[2] - a[2]);
                poly[n++] = new double[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, near};
            }
        }
        if (n < 3) return;

        double[] px = new double[n], py = new double[n];
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            px[i] = sw / 2.0 + poly[i][0] / (poly[i][2] * tanHalf * aspect) * (sw / 2.0);
            py[i] = sh / 2.0 - poly[i][1] / (poly[i][2] * tanHalf) * (sh / 2.0);
            minY = Math.min(minY, py[i]);
            maxY = Math.max(maxY, py[i]);
        }
        int y0 = (int) Math.max(0, Math.floor(minY)), y1 = (int) Math.min(sh - 1, Math.ceil(maxY));
        if (y0 > y1) return;
        int step = (y1 - y0) > 120 ? 2 : 1;
        for (int y = y0; y <= y1; y += step) {
            double yc = y + 0.5 * step;
            double xl = Double.MAX_VALUE, xr = -Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double ay = py[i], by = py[j];
                if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) {
                    double x = px[i] + (px[j] - px[i]) * ((yc - ay) / (by - ay));
                    xl = Math.min(xl, x);
                    xr = Math.max(xr, x);
                }
            }
            if (xr < xl) continue;
            int a = (int) Math.max(0, Math.floor(xl)), b = (int) Math.min(sw, Math.ceil(xr));
            if (b > a) ctx.fill(a, y, b, y + step, color);
        }
    }

    public static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2 + 1, y1 + 1, color);
        ctx.fill(x1, y2, x2 + 1, y2 + 1, color);
        ctx.fill(x1, y1, x1 + 1, y2 + 1, color);
        ctx.fill(x2, y1, x2 + 1, y2 + 1, color);
    }

    public static void label(DrawContext ctx, String text, int x, int y, int color) {
        int w = mc.textRenderer.getWidth(text);
        x = Math.max(2, Math.min(sw - w - 2, x));
        y = Math.max(2, Math.min(sh - 10, y));
        ctx.drawTextWithShadow(mc.textRenderer, text, x, y, color);
    }
}
