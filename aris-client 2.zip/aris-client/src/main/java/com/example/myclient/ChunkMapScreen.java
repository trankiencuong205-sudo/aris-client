package com.example.myclient;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;

/** Ban do chunk toan man hinh: cuon chuot de zoom, bam vao chunk tim thay de copy toa do. */
public class ChunkMapScreen extends Screen {
    private static int scale = 4;

    public ChunkMapScreen() { super(Text.literal("Aris ChunkMap")); }

    @Override
    public boolean shouldPause() { return false; }

    private double px() { return client.player.getX() / 16.0; }
    private double pz() { return client.player.getZ() / 16.0; }

    private int chunkAt(double mouse, double center, double player) {
        return (int) Math.floor((mouse - center) / scale + player);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (client == null || client.player == null) return;
        MapRenderer.draw(ctx, 0, 0, width, height, px(), pz(), scale);

        ctx.drawTextWithShadow(textRenderer,
                "Aris ChunkMap  |  cuon chuot: zoom  |  bam vao chunk mau: copy toa do  |  ESC: dong",
                6, 6, 0xFFFFFFFF);

        int cx = chunkAt(mouseX, width / 2.0, px());
        int cz = chunkAt(mouseY, height / 2.0, pz());
        String info = String.format("Chunk X=%d Z=%d", cx * 16 + 8, cz * 16 + 8);
        String desc = FoundChunks.describe(ChunkPos.toLong(cx, cz));
        if (desc != null) info += "  -  " + desc;
        ctx.drawTextWithShadow(textRenderer, info, 6, height - 12, 0xFFFFFFFF);

        // chu thich
        String[][] legend = {
                {"SusChunkFinder", "Nghi co nguoi"}, {"SpawnerFinder", "Spawner"},
                {"StashFinder", "Nhieu thung chua"}, {"LightFinder", "Nguon sang"}
        };
        int y = 20;
        for (String[] l : legend) {
            ctx.fill(6, y, 14, y + 8, FoundChunks.colorFor(l[0]));
            ctx.drawTextWithShadow(textRenderer, l[1], 18, y, 0xFFDDDDEE);
            y += 11;
        }
        ctx.drawTextWithShadow(textRenderer,
                "Bat SusChunkFinder / StashFinder... trong menu roi di chuyen de ban do hien chunk.",
                6, y + 4, 0xFF9A9AAA);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (client == null || client.player == null) return false;
        int cx = chunkAt(click.x(), width / 2.0, px());
        int cz = chunkAt(click.y(), height / 2.0, pz());
        if (FoundChunks.describe(ChunkPos.toLong(cx, cz)) != null) {
            String coords = (cx * 16 + 8) + " " + (cz * 16 + 8);
            client.keyboard.setClipboard(coords);
            client.player.sendMessage(Text.literal("Da copy toa do: " + coords), false);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scale = Math.max(1, Math.min(16, scale + (verticalAmount > 0 ? 1 : -1)));
        return true;
    }
}
