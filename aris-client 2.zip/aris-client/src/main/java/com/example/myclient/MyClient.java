package com.example.myclient;

import com.example.myclient.modules.ChunkMap;
import com.example.myclient.modules.Hud;
import com.example.myclient.modules.Watermark;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MyClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("myclient", "main"));

    public static ModuleManager modules;
    private static KeyBinding openGui;
    private static KeyBinding openMap;
    private static KeyBinding openRegions;

    @Override
    public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        openMap = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myclient.map", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, CATEGORY));

        openRegions = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myclient.regions", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, CATEGORY));

        modules = new ModuleManager();
        modules.get(Hud.class).setEnabled(true);
        modules.get(Watermark.class).setEnabled(true);
        modules.get(ChunkMap.class).setEnabled(true);
        modules.load();

        // vao server / world moi thi xoa du lieu ban do cu
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> FoundChunks.clear());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) client.setScreen(new ClickGui());
            while (openMap.wasPressed()) {
                if (client.player != null) client.setScreen(new ChunkMapScreen());
            }
            while (openRegions.wasPressed()) {
                if (client.player != null) client.setScreen(new RegionMapScreen());
            }
            if (client.player != null && client.world != null) modules.tick();
        });

        HudElementRegistry.addLast(Identifier.of("myclient", "hud"), (context, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;

            int y = 4;
            if (modules.get(Watermark.class).isEnabled()) {
                context.drawTextWithShadow(mc.textRenderer, "Aris Client", 4, y, 0xFF55FFFF);
                y += 11;
            }
            if (modules.get(Hud.class).isEnabled()) {
                for (Module m : modules.getModules()) {
                    if (m.isEnabled() && !(m instanceof Hud) && !(m instanceof Watermark)) {
                        context.drawTextWithShadow(mc.textRenderer, m.getName(), 4, y, 0xFFFFFFFF);
                        y += 10;
                    }
                }
            }

            ChunkMap map = (ChunkMap) modules.get(ChunkMap.class);
            if (map != null && map.isEnabled()) {
                int size = (map.radius.get() * 2 + 1) * map.zoom.get();
                int x0 = context.getScaledWindowWidth() - size - 6;
                MapRenderer.draw(context, x0, 6, size, size,
                        mc.player.getX() / 16.0, mc.player.getZ() / 16.0, map.zoom.get());
            }

            for (Module m : modules.getModules()) {
                if (m.isEnabled()) m.onHudRender(context);
            }
        });
    }
}
