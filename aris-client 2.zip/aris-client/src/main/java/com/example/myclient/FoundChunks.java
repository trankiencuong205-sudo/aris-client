package com.example.myclient;

import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Kho chung: chunk da quet va chunk ma cac module tim thay. Ban do (minimap + toan man hinh) doc tu day. */
public final class FoundChunks {
    private FoundChunks() {}

    public static final Set<Long> scanned = new HashSet<>();
    /** key chunk -> (ten module -> so block tim thay) */
    public static final Map<Long, Map<String, Integer>> found = new HashMap<>();
    /** key chunk -> 16 do cao mat dat (luoi 4x4 o, moi o 4x4 block) de to mau om theo dia hinh */
    public static final Map<Long, int[]> ground = new HashMap<>();

    private static final String[] ORDER = {
            "SpawnerFinder", "SusChunkFinder", "StashFinder", "ChunkFinder", "LightFinder"
    };

    public static void clear() {
        scanned.clear();
        found.clear();
        ground.clear();
    }

    public static void clearType(String type) {
        found.values().removeIf(m -> {
            m.remove(type);
            return m.isEmpty();
        });
    }

    public static void recordGround(WorldChunk chunk, int cx, int cz) {
        int[] h = new int[16];
        for (int gz = 0; gz < 4; gz++) {
            for (int gx = 0; gx < 4; gx++) {
                h[gz * 4 + gx] = chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, gx * 4 + 2, gz * 4 + 2) + 1;
            }
        }
        ground.put(ChunkPos.toLong(cx, cz), h);
    }

    public static void markScanned(int cx, int cz) { scanned.add(ChunkPos.toLong(cx, cz)); }

    public static void add(String type, int cx, int cz, int count) {
        found.computeIfAbsent(ChunkPos.toLong(cx, cz), k -> new HashMap<>()).put(type, count);
    }

    public static int colorFor(String type) {
        return switch (type) {
            case "SusChunkFinder" -> 0xFFFF4040;
            case "SpawnerFinder" -> 0xFFB060FF;
            case "StashFinder", "ChunkFinder" -> 0xFFFF9A2E;
            case "LightFinder" -> 0xFFFFE040;
            default -> 0xFFFFFFFF;
        };
    }

    public static int topColor(Map<String, Integer> types) {
        for (String t : ORDER) if (types.containsKey(t)) return colorFor(t);
        return 0xFFFFFFFF;
    }

    public static int chunkX(long key) { return (int) key; }
    public static int chunkZ(long key) { return (int) (key >>> 32); }

    public static String describe(long key) {
        Map<String, Integer> types = found.get(key);
        if (types == null) return null;
        StringBuilder sb = new StringBuilder();
        for (String t : ORDER) {
            if (types.containsKey(t)) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(t).append(" x").append(types.get(t));
            }
        }
        return sb.toString();
    }
}
