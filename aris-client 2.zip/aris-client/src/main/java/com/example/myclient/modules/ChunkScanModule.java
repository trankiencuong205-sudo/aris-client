package com.example.myclient.modules;

import com.example.myclient.Category;
import com.example.myclient.FoundChunks;
import com.example.myclient.IntSetting;
import com.example.myclient.Module;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Set;

/** Quet cac chunk client da nhan, bao toa do chunk co du so block entity mong muon. */
public abstract class ChunkScanModule extends Module {
    private static final int INTERVAL = 40; // 2 giay

    private final Set<Long> reported = new HashSet<>();
    private final String label;
    private final IntSetting threshold;
    private int lastThreshold;
    private int ticks;

    protected ChunkScanModule(String name, int key, String label, int defaultThreshold) {
        super(name, Category.BASEFINDING, key);
        this.label = label;
        this.threshold = intSetting("MinBlocks", defaultThreshold, 1, 200, 1);
        this.lastThreshold = threshold.get();
    }

    protected abstract boolean counts(BlockEntity be);

    @Override
    protected void onEnable() {
        reported.clear();
        FoundChunks.clearType(getName());
        ticks = INTERVAL; // quet ngay lan dau
        lastThreshold = threshold.get();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(String.format(
                    "[%s] Dang quet: bao chunk co tu %d %s tro len (chuot phai module trong menu de chinh).",
                    getName(), threshold.get(), label)), false);
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (threshold.get() != lastThreshold) {
            lastThreshold = threshold.get();
            reported.clear();
            FoundChunks.clearType(getName());
        }
        if (++ticks < INTERVAL) return;
        ticks = 0;

        int r = mc.options.getViewDistance().getValue();
        int pcx = mc.player.getChunkPos().x;
        int pcz = mc.player.getChunkPos().z;

        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                FoundChunks.markScanned(cx, cz);
                long key = ChunkPos.toLong(cx, cz);
                if (reported.contains(key)) continue;

                int count = 0;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (counts(be)) count++;
                }
                if (count >= threshold.get()) {
                    reported.add(key);
                    FoundChunks.add(getName(), cx, cz, count);
                    FoundChunks.recordGround(chunk, cx, cz);
                    mc.player.sendMessage(Text.literal(String.format(
                            "[%s] %d %s tai X=%d Z=%d", getName(), count, label, cx * 16 + 8, cz * 16 + 8)), false);
                }
            }
        }
    }
}
