package com.example.myclient.modules;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

import java.util.Set;

/** Bao chunk co nguon sang (duoc, den long, glowstone...) duoi long dat, thuong la dau hieu co nguoi o. */
public class LightFinder extends BlockScanModule {
    private static final Set<Block> BLOCKS = Set.of(
            Blocks.TORCH, Blocks.WALL_TORCH, Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH,
            Blocks.LANTERN, Blocks.SOUL_LANTERN, Blocks.GLOWSTONE, Blocks.SEA_LANTERN);

    public LightFinder() { super("LightFinder", -1, "nguon sang duoi long dat", 3, -64, 40, false); }

    @Override
    protected boolean counts(BlockState state) { return BLOCKS.contains(state.getBlock()); }
}
