# Aris Client (Fabric 1.21.11, Yarn)

ClickGUI: Right Shift de mo, ESC de dong.
- Bam tieu de panel de thu gon/mo rong.
- Bam module de bat/tat (cong tac gat).
- Go vao o "Find a module..." de loc module.
- Nut Save / Load: luu / tai danh sach module dang bat (file config/myclient-modules.txt).
  Config duoc tu dong tai khi khoi dong game.

Phim tat: G = Sprint, H = Fullbright, J = Fly, K = StashFinder, L = ChunkFinder. Nut Theme trong GUI doi giua giao dien Dark, Blue va Rainbow.

Build: `gradlew build` -> build/libs/myclient-1.0.0.jar, bo vao thu muc mods cung Fabric Loader + Fabric API.
Chay thu: `gradlew runClient`.

Neu Gradle bao loi version: tao project moi o https://fabricmc.net/develop/template/ (chon 1.21.11 + Yarn),
roi chep thu muc `src/` cua project nay de len.

Them module: tao class extends Module (category, phim tat hoac -1), them vao ModuleManager.

Cai dat module: trong menu, bam CHUOT PHAI vao module co dau ">" de mo cai dat (MinBlocks, MinY, MaxY...), bam - / + de chinh.
Cai dat duoc luu bang nut Save.

Ban do chunk: phim N (hoac nut Map trong menu) mo ban do toan man hinh, cuon chuot de zoom, bam chunk co mau de copy toa do.
Minimap o goc phai tren (module ChunkMap, chuot phai de chinh Radius / Zoom). Chunk mau do = SusChunkFinder (quet quanh mat dat), tim = spawner, cam = nhieu thung chua, vang = nguon sang.

ESP: bat StorageESP (khung + day noi toi ruong/barrel/shulker/spawner, chon loai trong cai dat) va ChunkESP (day noi toi chunk Sus/Spawner/Stash).
Ve bang phep chieu 3D -> 2D tren HUD. De day noi khop tuyet doi: Video Settings > FOV Effects = 0 (hoac chinh FovPercent).
SusChunkFinder co IgnoreVillage (bo qua lang NPC).

ChunkESP co che do Fill: to mau do len chunk nghi (om theo mat dat, nhu Krypton). Chinh FillAlpha (do dac), MaxFill (so chunk), FillRange (tam xa).

Region Map: phim M (hoac nut Grid trong menu) mo ban do vung danh so (luoi o xoan oc tu giua, to mau theo vong, cham do = vi tri ban).
RegionMap trong menu: chuot phai de chinh RegionSize (block moi o), CellsPerSide, FollowPlayer. Bat module de hien "Region N" tren HUD.
Luu y: so vung va kich thuoc o la cua client nay (tuy chinh duoc), khong nhat thiet trung voi vung that cua tung server.
